#include <iostream>
#include <unistd.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <vector>
#include <csignal>
#include <sys/wait.h>
#include <sys/stat.h>

using namespace std;

void printenv(const char* env_name);
bool isValid(const char* cmd);
void unknown(const char* cmd);
void zombie_deal(int sig);

int main(int argc, char **argv, char **envp)
{
	char input[15004];
	char buffer[10000000];
	char pipeNum_char[8];
	char rbuf[65536];
	bool isRedirect = false;
	int pipeNum_o = 0; //numbered-pipe stdout
	int pipeNum_err = 0; //numbered-pipe stderr/stdout
	int pipeCount = 0; // Num ordinary pipe
	vector<char**> input_cmd;
	
	char **temp_cmd;
	int cmd_counter = 0;
	int n;

	int pipefd[2];
	int pipefd_back[2]; // redirect pipe output to parent
	int pipeNum_counter[1004][2]; // numbered-pipe counter, store read/write fd
	int stdout_fd = dup(1); // save stdout fd
	int stdin_fd = dup(0); // save stdin fd
	int stderr_fd = dup(2);
	
	// initialize PATH
	setenv("PATH","bin:.",1);
	
	// initialize buffer
	memset(buffer,0,sizeof(buffer));	
	memset(rbuf,0,sizeof(rbuf));	

	// initialize numbered-pipe counter
	for(int i=0;i<1004;i++)
	{
		pipeNum_counter[i][0] = -1;
		pipeNum_counter[i][1] = -1;
	}

	while(true)
	{
		//initialize flag
		isRedirect = false;
		pipeNum_o = 0;
		pipeNum_err = 0;
		pipeCount = 0;
		temp_cmd = new char*[10];
		cmd_counter = 0;

		//for(int i=0;i<5;i++) printf("%d:%d %d\n",i,pipeNum_counter[i][0],pipeNum_counter[i][1]);
		
		printf("%s ","%");
		
		//get single line ipnut
		memset(input,0,sizeof(input));
		cin.getline(input,15004);
		if (cin.eof()) break;
		
		//split input
		char* hold = strtok(input," ");
		
		while(hold)
		{
			//check if redirect/pipe/numbered-pipe(stdout/stdout&stderr)
			if(!strcmp(hold,">"))
			{
				isRedirect = true;
				*(temp_cmd + cmd_counter) = NULL;
				input_cmd.push_back(temp_cmd); // store command line into vector
				temp_cmd = new char*[10];
				cmd_counter = 0;
			}
			else if(!strcmp(hold,"|"))
			{
				pipeCount++;
				*(temp_cmd + cmd_counter) = NULL;
				input_cmd.push_back(temp_cmd); // store command line into vector
				temp_cmd = new char*[10];
				cmd_counter = 0;

			}
			else if((!strncmp(hold,"|",1) || !strncmp(hold,"!",1) ) && strcmp(hold,"|"))
			{
				//convert char array to int
				memset(pipeNum_char,0,8);
				strncpy(pipeNum_char,hold+1,strlen(hold)-1);
				int num = atoi(pipeNum_char);
				int temp = num;
				int len = 0;
				while(temp) //get integer length
				{
					len++;
					temp/=10;
				}

				if(len == strlen(pipeNum_char)) //check if char array are all number
				{
					if(!strncmp(hold,"|",1))pipeNum_o = num;
					else pipeNum_err = num;
				}
				else
				{
					bool error = false;
					for(int k=0;k<strlen(pipeNum_char);k++)
					{
						if( (pipeNum_char[k] - '0' < 0 || pipeNum_char[k] - '0' > 9 ) && pipeNum_char[k] != '+')
						{
							error = true;
							break;
						}
						
					}
					
					if(!error)
					{
						int sum = 0;
						char* num_hold = strtok(pipeNum_char,"+");
					       	while(num_hold)
						{
							int number = atoi(num_hold);
							sum+=number;
							num_hold = strtok(NULL,"+");
						}
						if(!strncmp(hold,"|",1)) pipeNum_o = sum;
						else pipeNum_err = sum;
					}
					else
					{
						printf("Error numbered-pipes!\n");
						exit(0);
					}
				}
			}
			else // command token
			{

				*(temp_cmd + cmd_counter) = new char[strlen(hold)+1];
				memset(*(temp_cmd + cmd_counter),0,sizeof(*(temp_cmd + cmd_counter)));
				strcpy(*(temp_cmd+cmd_counter++),hold);
			}

			hold = strtok(NULL," ");

		}
		*(temp_cmd + cmd_counter) = NULL;

		input_cmd.push_back(temp_cmd); // store last command line into vector
		
		// check if input is empty
		if(*(input_cmd[0]) == NULL)
		{
			input_cmd.clear();
			continue;
		}	
		
		// substract counter
		for(int i=0;i<1004;i++)
		{
			if(i!=1003)
			{
				pipeNum_counter[i][0] = pipeNum_counter[i+1][0];
				pipeNum_counter[i][1] = pipeNum_counter[i+1][1];
			}
			else
			{
				pipeNum_counter[i][0] = -1;
				pipeNum_counter[i][0] = -1;
			}

		}
		// execute command
		if(!strcmp(*(input_cmd[0]),"setenv"))
		{
			setenv(*(input_cmd[0]+1),*(input_cmd[0]+2),1);
			input_cmd.clear();
			continue;
		}
		else if(!strcmp(*(input_cmd[0]),"printenv")) 
		{
			printenv(*(input_cmd[0]+1));
			input_cmd.clear();
			continue;
		}
		else if(!strcmp(*(input_cmd[0]),"exit")) break;

		for(int i=0;i<=pipeCount;i++)
		{
			pid_t pid;
			pipe(pipefd);
			pipe(pipefd_back);
			
			pid = fork();
			
			if(pid < 0)
			{
				printf("Fork failed!!\n");
				exit(-1);
			}
			else if(pid == 0) // child
			{
				// check if numbered-pipe output as stdin
				if(pipeNum_counter[0][0] != 0 && i == 0)
				{
					close(pipeNum_counter[0][1]);
					dup2(pipeNum_counter[0][0],0);
					close(pipeNum_counter[0][0]);
				}
				
				close(pipefd[1]);
				// first round may have numbered-pipe input, can't use parent pipe input as stdin
				if(i!=0) dup2(pipefd[0],0);
				close(pipefd[0]);
				
				// last round, need to redirect output directly instead of pipe to parent	
				if(i == pipeCount)
				{
					if(isRedirect && isValid(*(input_cmd[i]))) // file redirect
					{
						FILE* fptr;
						fptr = fopen(*(input_cmd[input_cmd.size()-1]),"w");
						dup2(fileno(fptr),1);
						execvp(*(input_cmd[i]),input_cmd[i]);	
					}
					else if(pipeNum_o != 0) // numbered-pipe (stdout)
					{
						// if the pipe is existed, reuse it, if not, redirect output to the new pipe,
						// and the new pipefd would be stored in parent.
						if(pipeNum_counter[pipeNum_o][0] !=-1)
						{
							close(pipefd_back[0]);
							close(pipefd_back[1]);
							dup2(pipeNum_counter[pipeNum_o][1],1);
						}
						else
						{
							close(pipefd_back[0]);
							dup2(pipefd_back[1],1);
							close(pipefd_back[1]);
						}
						// check input command is valid or not
						if(!isValid(*(input_cmd[i])))
						{
							unknown(*(input_cmd[i]));
							exit(0);
						}
						else execvp(*(input_cmd[i]),input_cmd[i]);
					}
					else if(pipeNum_err != 0) // numbered-pipe (stdout & stderr)
					{
						if(pipeNum_counter[pipeNum_err][0] !=-1)
						{
							close(pipefd_back[0]);
							close(pipefd_back[1]);
							dup2(pipeNum_counter[pipeNum_err][1],1);
							dup2(pipeNum_counter[pipeNum_err][1],2); // also pipe output to stderr
						}
						else
						{
							close(pipefd_back[0]);
							dup2(pipefd_back[1],1);
							dup2(pipefd_back[1],2);
							close(pipefd_back[1]);
						}
						if(!isValid(*(input_cmd[i]))) 
						{
							unknown(*(input_cmd[i]));
							exit(0);
						}
						else execvp(*(input_cmd[i]),input_cmd[i]);
						
					}
					else
					{	
						close(pipefd_back[0]);
						dup2(stdout_fd,1);
						close(pipefd_back[1]);
						
						if(!isValid(*(input_cmd[i]))) 
						{
							unknown(*(input_cmd[i]));
							exit(0);
						}
						else execvp(*(input_cmd[i]),input_cmd[i]);
					}
				}
				else // not last round
				{
					close(pipefd_back[0]);
					dup2(pipefd_back[1],1);
					close(pipefd_back[1]);
						
					if(!isValid(*(input_cmd[i]))) 
					{
						unknown(*(input_cmd[i]));
						exit(0);
					}
					else execvp(*(input_cmd[i]),input_cmd[i]);
				}
			}
			else // parent
			{
				// if numbered-pipe output already as stdin in this round, close the fd
				if(pipeNum_counter[0][0] != 0 && i == 0)
				{
					close(pipeNum_counter[0][0]);
					close(pipeNum_counter[0][1]);
				}
				

				// if not first round parent may need to pipe the previous round's stdout as next round's stdin
				// I would store previous round's output into buffer and write to pipe in this round
				// since I dup pipefd write to stdout, so it won't get the EOF when I finish write
				// so I dup stdout fd to stdout to overwritten the fd, so the pipe would close and send EOF automatically.
				//
				// (addition) fork another child to send data, prevent large data block the pipe
				// since previous version, it would stock at write, although child is reading from pipefd and write to pipefd_back,
				// but if data large than 2*65535, the pipefd_back and pipefd would be full, parent write would be block.
				pid_t opid;
				if(i != 0)
				{
					opid = fork();
					
					if(opid < 0)
					{
						printf("Fork Failed!\n");
						exit(-1);
					}
					else if(opid == 0)
					{
						close(pipefd[0]);
						dup2(pipefd[1],1);
						close(pipefd[1]);
						write(1,buffer,strlen(buffer));
						dup2(stdout_fd,1);
						
						close(pipefd_back[0]);
						close(pipefd_back[1]);
						exit(0);
					}
					close(pipefd[0]);
					close(pipefd[1]);
				}
				else
				{
					close(pipefd[0]);
					close(pipefd[1]);
				}
				
				// not last round, need to read output from child 
				if(i!=pipeCount)
				{					
					
					// close the pipefd_back write, because it only need to read the command output from child
					close(pipefd_back[1]);
					dup2(pipefd_back[0],0);
					close(pipefd_back[0]);
					
					// clear buffer to ensure not mix with the previous round data
					memset(buffer,0,sizeof(buffer));
					memset(rbuf,0,sizeof(rbuf));
					while(((n = read(0,rbuf,sizeof(rbuf))) >0))
					{
						strcat(buffer,rbuf);
						memset(rbuf,0,sizeof(rbuf));
					}
					
					int status;
					waitpid(pid,&status,0);
					//signal(SIGCHLD,zombie_deal);
				
				}
				else // last round, only need to close pipefd and wait for child and store pipefd if there is numbered-pipe
				{
					
					if(pipeNum_o !=0 || pipeNum_err !=0)
					{
						if(pipeNum_counter[pipeNum_o][0] !=-1)
						{
							close(pipefd_back[1]);
							close(pipefd_back[0]);
						}
						else
						{	
							int num = pipeNum_o>pipeNum_err?pipeNum_o:pipeNum_err;
							pipeNum_counter[num][0] = pipefd_back[0];
							pipeNum_counter[num][1] = pipefd_back[1];
							
						}
						signal(SIGCHLD,zombie_deal);
					}
					else
					{
						close(pipefd_back[1]);
						close(pipefd_back[0]);
						
						int status;
						waitpid(pid,&status,0);
					}
				}
				// wait for the output child 
				int status;
				waitpid(opid,&status,0);
			}
			usleep(1000);
		} // end of pipeCount loop
	

		// restore stdin fd back to the stdin
		dup2(stdin_fd,0);
		input_cmd.clear();
	}
	

}

// check command is existed in environment PATH or not
bool cmdExisted(const char* cmd)
{
	char *path = strtok(getenv("PATH"),":");
	char file[12+strlen(cmd)];

	struct stat buf;
	// split printenv return to single path,and check the command is existed or not
	while(path)
	{
		memset(file,0,sizeof(file));
		snprintf(file,sizeof(file),"./%s/%s",path,cmd);	
		if(stat(file,&buf) == 0)  return true;		

		path = strtok(NULL,":");
	}	
		
	return false;

}

// print environment variable
void printenv(const char* env_name)
{
	if(getenv(env_name) != NULL) printf("%s\n",getenv(env_name));
}

// check input command is valid or not
bool isValid(const char* cmd)
{
	if(cmdExisted(cmd)) return true;
	else return false;
}

// print invalid command Error msg
void unknown(const char* cmd)
{
	char err[21+strlen(cmd)];
	memset(err,0,sizeof(err));	
	sprintf(err,"Unknown command: [%s].\n",cmd);
	write(2,err,sizeof(err));
}

void zombie_deal(int sig)
{
	int status;
	while(waitpid(-1,&status,WNOHANG)>0){}
}
