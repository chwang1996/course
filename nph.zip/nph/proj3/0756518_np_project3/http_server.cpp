#include <boost/asio.hpp>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <utility>
#include <unistd.h>
#include <regex>
#include <sys/wait.h>

using namespace std;
using namespace boost::asio;

io_service global_io_service;

void zombie_handler(int sig)
{
	int status;
	waitpid(0,&status,WNOHANG);
}

struct http_header
{
	char* method;
	char* request_uri;
	char* query_string;
	char* protocol;
	char* host;
	char* server_addr;
	char* server_port;
	char* remote_addr;
	char* remote_port;
	char* file_path;
};


class ServerSession : public enable_shared_from_this<ServerSession> 
{
private:
 	enum { max_length = 1024 };
  	ip::tcp::socket _socket;
  	char _data[max_length];

public:
  	ServerSession(ip::tcp::socket socket) : _socket(move(socket)) {}

  	void start() { __read__(); }

  	void __read__() 
	{
    		auto self(shared_from_this());
    		_socket.async_read_some( buffer(_data, max_length), [this, self](boost::system::error_code ec, std::size_t length) {
          		if (!ec) __parse__();
        	});
  	}
	
	
	void __parse__()
	{
		auto self(shared_from_this());
		
		http_header header;
  		char* line_token;
		char* token;
		char* line_token2;
		char* line_token3;
		char* file_path;
		char* protocol;
	    	line_token = strtok(_data,"\r\n");
		line_token2 = strtok(NULL,"\r\n");
				


		// get method
		token = strtok(line_token," ");
		
		header.method = new char[strlen(token)+1];
		strncpy(header.method,token,strlen(token)+1);
		
		// get request_uri
		token = strtok(NULL," ");
	
		header.request_uri = new char[strlen(token)+1];
		strncpy(header.request_uri,token,strlen(token)+1);
		
		// set protocol
		line_token3 = strtok(NULL," ");
		header.protocol = new char[strlen(line_token3)+1];
		strncpy(header.protocol,line_token3,strlen(line_token3)+1);
		protocol = new char[strlen(line_token3)+1];
		strncpy(protocol,line_token3,strlen(line_token3)+1);
		

		// get file_path
		token = strtok(token,"?");
		header.file_path = new char[strlen(token)+1];
		strncpy(header.file_path,token,strlen(token)+1);
		file_path = new char[strlen(token)+1];
		strncpy(file_path,token,strlen(token)+1);
		
		// get query_string
		token = strtok(NULL,"?");
		if(token)
		{
			header.query_string = new char[strlen(token)+1];
			strncpy(header.query_string,token,strlen(token)+1);
		}
		else header.query_string = NULL;
		
		
		// get host
		token = strtok(line_token2," ");
		token = strtok(NULL," ");
	
		header.host = new char[strlen(token)+1];
		strncpy(header.host,token,strlen(token)+1);
			
		token = strtok(NULL,":");
	  	
		//get server_addr
		ip::tcp::endpoint server_ep = _socket.local_endpoint();
		ip::address server_ad = server_ep.address();
		header.server_addr = new char[server_ad.to_string().length()+1];
		strncpy(header.server_addr,server_ad.to_string().c_str(),server_ad.to_string().length()+1);
	
		// get server port
		unsigned short server_port = server_ep.port();
		header.server_port = new char[6];
		memset(header.server_port,0,6);
		snprintf(header.server_port,6,"%u",(unsigned short)server_port);

		// get remote_addr
		ip::tcp::endpoint remote_ep = _socket.remote_endpoint();
		ip::address remote_ad = remote_ep.address();
		header.remote_addr = new char[remote_ad.to_string().length()+1];
		strncpy(header.remote_addr,remote_ad.to_string().c_str(),remote_ad.to_string().length()+1);
		
		// get client port
		unsigned short remote_port = remote_ep.port();
		header.remote_port = new char[6];
		memset(header.remote_port,0,6);
		snprintf(header.remote_port,6,"%u",(unsigned short)remote_port);
		
		__set_env__(header);
	
		pid_t pid;
		pid = fork();
		
		if(pid < 0)
		{
			printf("Fork failed\n");
			exit(0);
		}
		else if(pid == 0)
		{
			char* path;
			path = new char[strlen(file_path)+1];
			sprintf(path,".%s",file_path);	
			
			bool isCpp=false;
			for(int i=0;i<strlen(path);i++)
			{
				if(path[i] == '.' && path[i+1] == 'c' && path[i+2] == 'p' && path[i+3] == 'p' && i+3<strlen(path))
				{
					isCpp = true;
					string cmd = "clang++ " + string(path);
					system(cmd.c_str());
				}
			}			

			dup2(_socket.native_handle(),STDOUT_FILENO);
			dup2(_socket.native_handle(),STDIN_FILENO);
			memset(_data,0,sizeof(_data));
			sprintf(_data,"%s OK\r\n",protocol);
			__write__(strlen(_data));			
	
			_socket.close();
			
			if(isCpp) execl("a.out","a.out",NULL);
			else execl(path,path,NULL);
			
		}
		else
		{
			_socket.close();
			signal(SIGCHLD,zombie_handler);	
		}
	}


	void __set_env__(http_header header)
	{
		setenv("REQUEST_METHOD",header.method,1);
		setenv("REQUEST_URI",header.request_uri,1);
		if(header.query_string != NULL) setenv("QUERY_STRING",header.query_string,1);
		setenv("SERVER_PROTOCOL",header.protocol,1);
		setenv("HTTP_HOST",header.host,1);
		setenv("SERVER_ADDR",header.server_addr,1);
		setenv("SERVER_PORT",header.server_port,1);
		setenv("REMOTE_ADDR",header.remote_addr,1);
		setenv("REMOTE_PORT",header.remote_port,1);
		setenv("FILE_PATH",header.file_path,1);
		
		__delete_header__(header);
	}
	

	void __delete_header__(http_header header)
	{
		delete []header.method;
		delete []header.request_uri;
		if(header.query_string != NULL) delete []header.query_string;
		delete []header.protocol;
		delete []header.host;
		delete []header.server_addr;
		delete []header.server_port;
		delete []header.remote_addr;
		delete []header.remote_port;

	}

	void __write__(std::size_t length) 
	{
    		auto self(shared_from_this());
    		_socket.async_send( buffer(_data, length), 
		[this, self](boost::system::error_code ec, std::size_t /* length */) {
          		if (!ec) __empty_handler__();
        	});

  	}
	
	void __empty_handler__() {}
};

class Server 
{
private:
  	ip::tcp::acceptor _acceptor;
  	ip::tcp::socket _socket;

public:
  	Server(short port)
      	: _acceptor(global_io_service, ip::tcp::endpoint(ip::tcp::v4(), port)),
        	_socket(global_io_service) {
    	do_accept();
  	}

private:
  	void do_accept() 
	{
    		_acceptor.async_accept(_socket, [this](boost::system::error_code ec) {
      			if (!ec) make_shared<ServerSession>(move(_socket))->start();
      			do_accept();
    		});
  	}
};

int main(int argc, char** argv)
{
	
	if (argc != 2) 
	{
		printf("Usage: %s <port>\n",argv[0]);
    		return 1;
  	}
	
  	try {
    		short port = atoi(argv[1]);
    		Server server(port);
    		global_io_service.run();
  	} catch (exception& e) {
    		printf("Exception: %s\n",e.what());
  	}

  return 0;
}
