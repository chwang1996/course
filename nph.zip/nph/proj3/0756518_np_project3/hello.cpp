#include <iostream>

using namespace std;

int main()
{
	cout<<"Content-type: text/html\r\n\r\n";
	cout<<"Hello World!"<<endl;


}
