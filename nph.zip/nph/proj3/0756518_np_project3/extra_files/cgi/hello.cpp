#include <iostream>
using namespace std;

int main() {
  /* [Required] HTTP Header */
  cout << "Content-type: text/html" << endl << endl;

  cout << "<h1>Hello</h1>" << endl;
  return 0;
}
