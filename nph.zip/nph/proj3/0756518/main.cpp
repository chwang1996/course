#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include <boost/asio.hpp>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <utility>
#include <cstring>
#include <fstream>

using namespace std;
using namespace boost::asio;

io_service global_io_service;

class Host 
{
public:
	char* hostname;
	char* server_addr;
	char* port;
	char* file_path;
	ifstream fin;
	bool valid;	

	ip::tcp::socket _socket_remote;
	char _data[81920];

	Host() : _socket_remote(global_io_service) {}
};



struct http_header
{
	char* method;
	char* request_uri;
	char* query_string;
	char* protocol;
	char* host;
	char* server_addr;
	char* server_port;
	char* remote_addr;
	char* remote_port;
	char* file_path;
};





class ServerSession : public enable_shared_from_this<ServerSession> 
{
private:
 	enum { max_length = 81920 };
  	ip::tcp::socket _socket;
  	char _data[max_length];
  	Host host[5];

public:
  	ServerSession(ip::tcp::socket socket) : _socket(move(socket)) { }

  	void start() { __read__(); }

  	void __read__() 
	{
    		auto self(shared_from_this());
    		_socket.async_read_some( buffer(_data, max_length), [this, self](boost::system::error_code ec, std::size_t length) {
          		if (!ec) __parse__();
        	});
  	}
	
	
	void __parse__()
	{
		auto self(shared_from_this());
		
		http_header header;
  		char* line_token;
		char* token;
		char* line_token2;
		char* line_token3;
	    line_token = strtok(_data,"\r\n");
		line_token2 = strtok(NULL,"\r\n");
				


		// get method
		token = strtok(line_token," ");
		
		header.method = new char[strlen(token)+1];
		strncpy(header.method,token,strlen(token)+1);
		
		// get request_uri
		token = strtok(NULL," ");
	
		header.request_uri = new char[strlen(token)+1];
		strncpy(header.request_uri,token,strlen(token)+1);
		
		// set protocol
		line_token3 = strtok(NULL," ");
		header.protocol = new char[strlen(line_token3)+1];
		strncpy(header.protocol,line_token3,strlen(line_token3)+1);

		// get file_path
		token = strtok(token,"?");
		header.file_path = new char[strlen(token)+2];
		sprintf(header.file_path,".%s",token);
		
		// get query_string
		token = strtok(NULL,"?");
		if(token)
		{
			header.query_string = new char[strlen(token)+1];
			strncpy(header.query_string,token,strlen(token)+1);
		}
		else header.query_string = NULL;
		
		
		// get host
		token = strtok(line_token2," ");
		token = strtok(NULL," ");
	
		header.host = new char[strlen(token)+1];
		strncpy(header.host,token,strlen(token)+1);
			
		token = strtok(NULL,":");
	  	
		//get server_addr
		ip::tcp::endpoint server_ep = _socket.local_endpoint();
		ip::address server_ad = server_ep.address();
		header.server_addr = new char[server_ad.to_string().length()+1];
		strncpy(header.server_addr,server_ad.to_string().c_str(),server_ad.to_string().length()+1);
	
		// get server port
		unsigned short server_port = server_ep.port();
		header.server_port = new char[6];
		memset(header.server_port,0,6);
		snprintf(header.server_port,6,"%u",(unsigned short)server_port);

		// get remote_addr
		ip::tcp::endpoint remote_ep = _socket.remote_endpoint();
		ip::address remote_ad = remote_ep.address();
		remote_ad.to_string();	
		header.remote_addr = new char[remote_ad.to_string().length()+1];
		strncpy(header.remote_addr,remote_ad.to_string().c_str(),remote_ad.to_string().length()+1);
		
		// get client port
		unsigned short remote_port = remote_ep.port();
		header.remote_port = new char[6];
		memset(header.remote_port,0,6);
		snprintf(header.remote_port,6,"%u",(unsigned short)remote_port);
		
	
		memset(_data,0,sizeof(_data));
		sprintf(_data,"%s OK\r\n",header.protocol);
		__write__(strlen(_data));			
		
		if(!strcmp(header.file_path,"./panel.cgi")) __panel__();
		else if(!strcmp(header.file_path,"./console.cgi")) __console__(header);
	}


	void __panel__()
	{
		memset(_data,0,sizeof(_data));

		strcpy(_data,"Content-type: text/html\r\n\r\n");
		//snprintf(_data, strlen("Content-type: text/html\r\n\r\n"), "Content-type: text/html\r\n\r\n");
		string str = R"(<!DOCTYPE html>
		<html lang="en">
		  <head>
		    <title>NP Project 3 Panel</title>
		    <link
		      rel="stylesheet"
		      href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
		      integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
		      crossorigin="anonymous"
		    />
		    <link
		      href="https://fonts.googleapis.com/css?family=Source+Code+Pro"
		      rel="stylesheet"
		    />
		    <link
		      rel="icon"
		      type="image/png"
		      href="https://cdn4.iconfinder.com/data/icons/iconsimple-setting-time/512/dashboard-512.png"
		    />
		    <style>
		      * {
		        font-family: 'Source Code Pro', monospace;
		      }
		    </style>
		  </head>
		  <body class="bg-secondary pt-5">
		  <form action="console.cgi" method="GET">
		      <table class="table mx-auto bg-light" style="width: inherit">
		        <thead class="thead-dark">
		          <tr>
		            <th scope="col">#</th>
		            <th scope="col">Host</th>
		            <th scope="col">Port</th>
		            <th scope="col">Input File</th>
		          </tr>
		        </thead>
		        <tbody>
		        <tr>)";
        strcat(_data,str.c_str());
        for(int i=0;i<5;i++)
        {
	        str = R"( <th scope="row" class="align-middle">Session )"+to_string(i+1)+R"(</th>
	            <td>
	              <div class="input-group">
	                <select name="h)"+to_string(i)+R"(" class="custom-select">
	                  <option></option><option value="nplinux1.cs.nctu.edu.tw">nplinux1</option><option value="nplinux2.cs.nctu.edu.tw">nplinux2</option><option value="nplinux3.cs.nctu.edu.tw">nplinux3</option><option value="nplinux4.cs.nctu.edu.tw">nplinux4</option><option value="nplinux5.cs.nctu.edu.tw">nplinux5</option><option value="npbsd1.cs.nctu.edu.tw">npbsd1</option><option value="npbsd2.cs.nctu.edu.tw">npbsd2</option><option value="npbsd3.cs.nctu.edu.tw">npbsd3</option><option value="npbsd4.cs.nctu.edu.tw">npbsd4</option><option value="npbsd5.cs.nctu.edu.tw">npbsd5</option>
	                </select>
	                <div class="input-group-append">
	                  <span class="input-group-text">.cs.nctu.edu.tw</span>
	                </div>
	              </div>
	            </td>
	            <td>
	              <input name="p)"+to_string(i)+R"(" type="text" class="form-control" size="5" />
	            </td>
	            <td>
	              <select name="f)"+to_string(i)+R"(" class="custom-select">
	                <option></option>
	                <option value="t1.txt">t1.txt</option>
	                <option value="t2.txt">t2.txt</option>
	                <option value="t3.txt">t3.txt</option>
	                <option value="t4.txt">t4.txt</option>
	                <option value="t5.txt">t5.txt</option>
	                <option value="t6.txt">t6.txt</option>
	                <option value="t7.txt">t7.txt</option>
	                <option value="t8.txt">t8.txt</option>
	                <option value="t9.txt">t9.txt</option>
	                <option value="t10.txt">t10.txt</option>
	              </select>
	            </td>
	          </tr>
	        )";
			strcat(_data,str.c_str());
    	}
    	str = R"(<tr>
		            <td colspan="3"></td>
		            <td>
		              <button type="submit" class="btn btn-info btn-block">Run</button>
		            </td>
		          </tr>
		        </tbody>
		      </table>
		    </form>
		  </body>
		</html>)";
		strcat(_data,str.c_str());
		__write__(strlen(_data));
		
		memset(_data,0,sizeof(_data));
	}

	void __console__(http_header header)
	{
		get_env(header);
	
		preoutput();

		for(int i=0;i<5;i++)
		{
			if(host[i].valid) __resolve_connect__(i);
		}

	}


	void __resolve_connect__(int _index)
	{
		ip::tcp::resolver _resolver(global_io_service);
		ip::tcp::resolver::query _query(host[_index].hostname,host[_index].port);
		connect(host[_index]._socket_remote,_resolver.resolve(_query));
		
		memset(host[_index]._data,0,max_length);
		__read_remote__(_index);
		
	}

	void __read_remote__(int _index) 
	{
    	auto self(shared_from_this());
		bool prompt = false;
		for(int i=0;i<strlen(host[_index]._data);i++)
		{
			if(host[_index]._data[i] == '%' && i!= strlen(host[_index]._data)-1 && host[_index]._data[i+1] == ' ')
			{
				prompt = true;
				break;
			}
		}		

		if(prompt) 
		{
			__output_shell__(_index);
			memset(host[_index]._data,0,sizeof(host[_index]._data));

			string buf;
			if(!host[_index].fin.eof())
			{
				getline(host[_index].fin,buf);
				sprintf(host[_index]._data,"%s\n",buf.c_str());
				__output_command__(_index);
				__write_remote__(strlen(host[_index]._data),_index);
			}
		
		}
		else if(strlen(host[_index]._data)!=0)
		{
			__output_shell__(_index);
		}	
		
		memset(host[_index]._data,0,sizeof(host[_index]._data));
		if(_index == 0)  host[_index]._socket_remote.async_receive( buffer(host[_index]._data, max_length), [this, self](boost::system::error_code ec, std::size_t length) {
          		if (!ec) __read_remote0_handler__();  });
		else if(_index == 1)  host[_index]._socket_remote.async_receive( buffer(host[_index]._data, max_length), [this, self](boost::system::error_code ec, std::size_t length) {
          		if (!ec) __read_remote1_handler__();  });
		else if(_index == 2)  host[_index]._socket_remote.async_receive( buffer(host[_index]._data, max_length), [this, self](boost::system::error_code ec, std::size_t length) {
          		if (!ec) __read_remote2_handler__();  });
		else if(_index == 3)  host[_index]._socket_remote.async_receive( buffer(host[_index]._data, max_length), [this, self](boost::system::error_code ec, std::size_t length) {
          		if (!ec) __read_remote3_handler__();  });
		else if(_index == 4)  host[_index]._socket_remote.async_receive( buffer(host[_index]._data, max_length), [this, self](boost::system::error_code ec, std::size_t length) {
          		if (!ec) __read_remote4_handler__();  });
  	}

  	void __read_remote0_handler__() { __read_remote__(0); }
  	void __read_remote1_handler__() { __read_remote__(1); }
  	void __read_remote2_handler__() { __read_remote__(2); }
  	void __read_remote3_handler__() { __read_remote__(3); }
  	void __read_remote4_handler__() { __read_remote__(4); }


  	void __output_shell__(int _index)
	{
		string _data_str = __escape__(string(host[_index]._data));
		memset(_data,0,sizeof(_data));

		sprintf(_data,"<script>document.getElementById('s%d').innerHTML += '%s';</script>",_index,_data_str.c_str());
		__write__(strlen(_data));
	}

	void __output_command__(int _index)
	{
		string _data_str = __escape__(string(host[_index]._data));
		memset(_data,0,sizeof(_data));

		sprintf(_data,"<script>document.getElementById('s%d').innerHTML += '<b>%s</b>';</script>",_index,_data_str.c_str());
		__write__(strlen(_data));
	}

	string __escape__(string data)
	{ 
		string buffer;
    		buffer.reserve(data.size());
    		for(int pos = 0; pos != data.size(); pos++) 
		{
        		switch(data[pos]) 
			{
            			case '&':  buffer.append("&amp;");       break;
            			case '\"': buffer.append("&quot;");      break;
            			case '\'': buffer.append("&apos;");      break;
            			case '<':  buffer.append("&lt;");        break;
            			case '>':  buffer.append("&gt;");        break;
            			case '!':  buffer.append("&#33;");        break;
            			case '\t': buffer.append("&#09;");        break;
            			case '\n': buffer.append("&NewLine;");   break;
            			case '\r': buffer.append("&#13;");   break;
            			case '|': buffer.append("&vert;");	 break;
            			case '%': buffer.append("&#37;");	 break;
            			case '-': buffer.append("&#45;");	 break;
            			case '.': buffer.append("&#46;");	 break;
            			case ':': buffer.append("&#58;");	 break;
            			case ' ': buffer.append("&nbsp;");	 break;
            			default:   buffer.append(&data[pos], 1); break;
        		}
    		}
    		data.swap(buffer);
		return data;
	}

	void preoutput()
	{
		memset(_data,0,sizeof(_data));

		strcpy(_data,"Content-type: text/html\r\n\r\n");
		string str;
		str = R"(<!DOCTYPE html>
		<html lang="en">
		  <head>
		    <meta charset="UTF-8" />
		    <title>NP Project 3 Console</title>
		    <link
		      rel="stylesheet"
		      href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
		      integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO"
		      crossorigin="anonymous"
		    />
		    <link
		      href="https://fonts.googleapis.com/css?family=Source+Code+Pro"
		      rel="stylesheet"
		    />
		    <link
		      rel="icon"
		      type="image/png"
		      href="https://cdn0.iconfinder.com/data/icons/small-n-flat/24/678068-terminal-512.png"
		    />
		    <style>
		      * {
		        font-family: 'Source Code Pro', monospace;
		        font-size: 1rem !important;
		      }
		      body {
		        background-color: #212529;
		      }
		      pre {
		        color: #cccccc;
		      }
		      b {
		        color: #ffffff;
		      }
		    </style>
		  </head>
		  <body>
		    <table class="table table-dark table-bordered">
		      <thead>
		        <tr>)";

		strcat(_data,str.c_str());

		for(int i=0;i<5;i++) 
		{
			if(host[i].valid)
			{
				str = R"(<th scope="col">)" + string(host[i].hostname) + ":" + string(host[i].port) + "</th>";
				strcat(_data,str.c_str());
			}

		}
		
	        
		str = R"(</tr>
	      </thead>
	      <tbody>
	        <tr>)";
	    strcat(_data,str.c_str());

		for(int i=0;i<5;i++) 
		{
			if(host[i].valid)
			{
				str = R"(<td><pre id="s)"+to_string(i)+R"(" class="mb-0"></pre></td>)";
				strcat(_data,str.c_str());
			}

		}
	        
		str = R"(</tr>
		      </tbody>
		    </table>
		  </body>
		</html>)";
		strcat(_data,str.c_str());
		
		__write__(strlen(_data));
		memset(_data,0,sizeof(_data));
	}

	void get_env(http_header header)
{
	char hostname[32];
	char* token;
	char file_path[60];
	char port[8];
	int index;
		
	token = strtok(header.query_string,"&");
	
	while(token!=NULL)
	{
		memset(hostname,0,32);
		memset(file_path,0,60);
		memset(port,0,8);
		
		sscanf(token,"h%d=%s",&index,hostname);
		
		token = strtok(NULL,"&");
		sscanf(token,"p%d=%s",&index,port);
			
		token = strtok(NULL,"&");
		sscanf(token,"f%d=%s",&index,file_path);
		
		token = strtok(NULL,"&");
		if(hostname[0] == '\0' || port[0] == '\0' || file_path[0] == '\0') 
		{
			host[index].valid = false;
			continue;
		}
	
		
		// set to host[index]	
		host[index].hostname = new char[strlen(hostname)+1];
		strcpy(host[index].hostname,hostname);
		
		host[index].port = new char[strlen(port)+1];
		strcpy(host[index].port,port);


		host[index].file_path = new char[strlen(file_path)+11];
		sprintf(host[index].file_path,"test_case/%s",file_path);
			
		host[index].fin.open(host[index].file_path);	

		host[index].valid = true;
	}

}

	void __write__(std::size_t length) 
	{
    	auto self(shared_from_this());
    	_socket.async_send( buffer(_data, length), 
		[this, self](boost::system::error_code ec, std::size_t /* length */) {
          		if (!ec) __empty_handler__();
        	});

  	}

  	void __write_remote__(std::size_t length,int _index) 
	{
    		auto self(shared_from_this());
    		host[_index]._socket_remote.async_send( buffer(host[_index]._data, length), 
		[this, self](boost::system::error_code ec, std::size_t /* length */) {
          		if (!ec) __empty_handler__();
        	});

  	}
	
	void __empty_handler__() {}
};

class Server 
{
private:
  	ip::tcp::acceptor _acceptor;
  	ip::tcp::socket _socket;

public:
  	Server(short port)
      	: _acceptor(global_io_service, ip::tcp::endpoint(ip::tcp::v4(), port)),
        	_socket(global_io_service) {
    	do_accept();
  	}

private:
  	void do_accept() 
	{
    		_acceptor.async_accept(_socket, [this](boost::system::error_code ec) {
      			if (!ec) make_shared<ServerSession>(move(_socket))->start();
      			do_accept();
    		});
  	}
};



int main(int argc, char** argv)
{
	
	if (argc != 2) 
	{
		printf("Usage: %s <port>\n",argv[0]);
    		return 1;
  	}
	
  	try {
    		short port = atoi(argv[1]);
    		Server server(port);
    		global_io_service.run();
  	} catch (exception& e) {
    		printf("Exception: %s\n",e.what());
  	}

  return 0;
}
