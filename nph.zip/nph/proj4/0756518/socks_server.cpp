#include <cstdlib>
#include <iostream>
#include <memory>
#include <utility>
#include <unistd.h>
#include <sys/wait.h>
#include <cstdio>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <csignal>
#include <cstring>
#include <vector>
#include <fstream>
#include <regex>

#define MAXBUFLINE 16000

using namespace std;

struct socks_reply
{
	uint8_t vn;
	uint8_t cd;
	uint16_t dst_port;
	struct in_addr dst_addr;
};


bool isPassFireWall(int,char*);
string ipToexp(string);
int __connection__(uint16_t,struct in_addr);
int __bind__(struct in_addr);
void transmission(int);
void run_socks(struct sockaddr_in);
void zombie_handler(int sig)
{
	int status;
	waitpid(0,&status,WNOHANG);
}


int main(int argc,char** argv)
{
	int listenfd,sockfd;
	socklen_t client_len = sizeof(struct sockaddr_in);
	struct sockaddr_in client_addr,server_addr;
	
	if(argc != 2)
	{
		printf("Usage:%s <port>\n",argv[0]);
		exit(-1);
	}

	signal(SIGCHLD,zombie_handler);

	// create server socket
	if((listenfd = socket(AF_INET,SOCK_STREAM,0)) < 0)
	{
		printf("Create Socket Failed!\n");
		exit(1);
	}
	
	bzero(&server_addr,sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	server_addr.sin_port = htons(atoi(argv[1]));
	
	// bind addrees to the server socket
  	if(bind(listenfd,(const struct sockaddr *) &server_addr,sizeof(server_addr)) < 0)
	{
		printf("Bind Failed!\n");
		exit(1);
	}

	// set max pending num
	listen(listenfd,10);

	while(true)
	{
		sockfd = accept(listenfd,(struct sockaddr*) &client_addr,&client_len);
		pid_t pid;
		pid = fork();
		
		if(pid < 0)
		{
			printf("Fork Failed\n");
			exit(-1);
		}
		else if(pid == 0)
		{
			dup2(sockfd,STDIN_FILENO);
			dup2(sockfd,STDOUT_FILENO);
			close(listenfd);
			close(sockfd);
			
			run_socks(client_addr);
		
			exit(0);
		}
		else if(pid > 0)
		{
			close(sockfd);
		}
		
	} 
	return 0;
}


void run_socks(struct sockaddr_in client_addr)
{
	char buf[MAXBUFLINE];
	int sockfd;	
	bool isPass = true;

	// read from socks request
	read(STDIN_FILENO,buf,MAXBUFLINE);
	
	uint8_t vn;
	uint8_t cd;
	uint16_t dst_port;
	struct in_addr dst_addr;

	memcpy(&vn,buf,1);
	memcpy(&cd,buf+1,1);
	memcpy(&dst_port,buf+2,2);
	memcpy(&dst_addr,buf+4,4);

	dst_port = ntohs(dst_port);

	socks_reply reply;
	reply.vn = 0;

		
	if(!isPassFireWall(cd,inet_ntoa(dst_addr)))
	{
		reply.cd = 91;
		reply.dst_addr = dst_addr;
		reply.dst_port = htons(dst_port);

		isPass = false;
	}	


	
	if(cd == 1 && isPass) // connection mode
	{
		if((sockfd = __connection__(dst_port,dst_addr)) < 0)
		{
			cerr << "Connection Failed" <<endl;
			reply.cd = 91;	
		}
		reply.dst_port = htons(dst_port);
		reply.dst_addr = dst_addr;
		reply.cd = 90;
		
	}
	else if (cd == 2 && isPass) // bind mode
	{
		if((sockfd = __bind__(dst_addr)) < 0)
		{
			cerr << "Connection Failed" <<endl;
			reply.cd = 91;	
		}
		reply.dst_port = htons(dst_port);
		reply.dst_addr = dst_addr;
		reply.cd = 90;

	}
	else if (isPass)
	{
		cerr<<"Error mode"<<endl;
		exit(-1);
	}
	
	// print socks server msg	
	cerr << "<S_IP>  :" << inet_ntoa(client_addr.sin_addr) << endl;
	cerr << "<S_PORT>  :" << client_addr.sin_port << endl;
	cerr << "<D_IP>  :" << inet_ntoa(dst_addr) << endl;
	cerr << "<D_PORT>  :" << dst_port << endl;
	if(cd == 1) cerr << "<Command>  :CONNECT" <<endl;
	else if(cd == 2) cerr << "<Command>  :BIND" <<endl;
	if(reply.cd == 90) cerr << "<Reply>  :Accept" <<endl;
	else if(reply.cd == 91) cerr << "<Reply>  :Reject" <<endl;
	cerr << endl;	

	// send socks reply
	write(STDOUT_FILENO,&reply,sizeof(socks_reply));

	// start to transmit http packet
	if(reply.cd == 90) transmission(sockfd);
	
	
}


int __connection__(uint16_t dst_port,struct in_addr dst_addr)
{
	int connectfd;
	struct sockaddr_in addr;
		
	if((connectfd = socket(AF_INET,SOCK_STREAM,0)) < 0)
	{
		cerr << "Create Socket Failed!" <<endl;
		exit(-1);
	}
	
	bzero(&addr,sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr = dst_addr;
	addr.sin_port = htons(dst_port);

	if(connect(connectfd,(const struct sockaddr *) &addr,sizeof(addr)) < 0)
	{
		cerr << "connection to destination Failed" <<endl;
		exit(-1);
	}

	return connectfd;
}


int __bind__(struct in_addr dst_addr)
{
	int bindfd,resultfd;
	struct sockaddr_in addr,sock_addr;
	socklen_t addr_len = sizeof(struct sockaddr_in);
	socklen_t sock_addr_len = sizeof(struct sockaddr_in);
	
	socks_reply reply;
	
	if((bindfd = socket(AF_INET,SOCK_STREAM,0)) < 0)
	{
		cerr << "Create Socket Failed!" <<endl;
		exit(-1);
	}
	
	bzero(&addr,sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(INADDR_ANY);
	
	// bind addrees to the server socket
  	if(bind(bindfd,(const struct sockaddr *) &addr,sizeof(addr)) < 0)
	{
		printf("Bind Failed!\n");
		exit(1);
	}

	// set max pending num
	listen(bindfd,10);

	
	getsockname(bindfd,(struct sockaddr *) &sock_addr,&sock_addr_len);

	reply.vn = 0;
	reply.cd = 90;
	reply.dst_port = sock_addr.sin_port;
	memset(&reply.dst_addr,0,sizeof(struct in_addr));
		
	// send socks reply
	write(STDOUT_FILENO,&reply,sizeof(socks_reply));

	addr_len = sizeof(struct sockaddr_in);
	if ((resultfd = accept (bindfd, (struct sockaddr *) &sock_addr, &sock_addr_len)) < 0) 
	{
		cerr << "Bind mode accept Failed" <<endl;
		return -1;
	}


	return resultfd;
}

void transmission (int connectfd)
{
	int max_fd = connectfd;
	int num_ready;
	int n;
	char buf[10000000];
	fd_set rset,allset;

	FD_ZERO(&allset);
	FD_SET(connectfd, &allset);
	FD_SET(STDIN_FILENO, &allset);


	for(;;) 
	{
		rset = allset;
		
		num_ready = select(max_fd+1,&rset,NULL,NULL,NULL);
		
		// src -> dst		
		if (FD_ISSET (STDIN_FILENO, &rset)) 
		{
			if((n = read(STDIN_FILENO, buf, 10000000)) <= 0)
			{
				FD_CLR (STDIN_FILENO, &allset);
				close (STDIN_FILENO);
				close (STDOUT_FILENO);
				exit(-1);
			} 
			else 
			{
				write (connectfd, buf, n);
			}
		}
		// dst -> src
		if (FD_ISSET (connectfd, &rset)) 
		{
			if((n = read(connectfd, buf, 10000000)) <= 0)
			{
				FD_CLR (connectfd, &allset);
				close (connectfd);
				exit(-1);
			} 
			else 
			{
				write(STDOUT_FILENO,buf,n);
			}
		}
	}

}


bool isPassFireWall(int mode,char* dst_addr)
{
	ifstream fin;
	fin.open("socks.conf");

	if(!fin.is_open())
        {
                cout<<"Can't open socks.conf"<<endl;
                exit(-1);
        }


	string buf;
	char* token;
	char line[100];

	while(!fin.eof())
	{
		memset(line,0,100);

		getline(fin,buf);
		sprintf(line,"%s",buf.c_str());

		token = strtok(line," ");
		token = strtok(NULL," ");
		if((*token == 'c' && mode == 1) || (*token == 'b' && mode == 2))
		{
			token = strtok(NULL," ");
	
			string exp(token);			
			exp = ipToexp(exp);
			regex reg(exp);
			if(regex_match(string(dst_addr),reg)) return true;					

		}
	}
	return false;

}

string ipToexp(string ip)
{
	string buffer;
        buffer.reserve(ip.size());
        for(int pos = 0; pos != ip.size(); pos++)
        {
                switch(ip[pos])
                {
                        case '.':  buffer.append("\\\."); break;
                        case '*':  buffer.append("(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)");       break;
                        default:   buffer.append(&ip[pos], 1); break;
                }
        }
        ip.swap(buffer);
        return ip;

}
