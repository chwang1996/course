#include <iostream>
//#include "unpv13e/unp.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <signal.h>
#include <unistd.h>
#include <cstdlib>
#include <cstring>
#include <cstdio>

#define MAXLINE 4096

using namespace std;


int main(int argc, char **argv)
{
	int  sockfd,maxfd;
	ssize_t n;
	struct addrinfo hint,*server_addr;
	char input[MAXLINE];
	fd_set rset,allset;
		
	short port;
	char message[MAXLINE];	
	//struct addrinfo hints, *res;	

	if(argc !=3) /* check if input argument */
	{
		cout<<"Error num of argument!"<<endl;
		return 0;
	}

		
	if ((sockfd = socket(AF_INET,SOCK_STREAM,0)) < 0) /* create sockfd */
	{
		cout<<"Create socket error!"<<endl;
		return 0;
	}
	bzero(&hint,sizeof(hint));
	hint.ai_family = AF_INET;
	hint.ai_socktype = SOCK_STREAM;
	getaddrinfo(argv[1],argv[2],&hint,&server_addr); /* get ip/domain name info */
		
  	if(connect(sockfd,server_addr->ai_addr,server_addr->ai_addrlen) < 0) /* connect to server */
	{
		cout<<"Connect error!"<<endl;
		return 0;
	}
	
	maxfd = STDIN_FILENO>sockfd ? STDIN_FILENO:sockfd;
	FD_ZERO(&allset);
	FD_SET(STDIN_FILENO,&allset);
	FD_SET(sockfd,&allset);


	for(;;)
	{
		rset = allset;
		select(maxfd+1,&rset,NULL,NULL,NULL);
		
		if(FD_ISSET(sockfd,&rset))  /* check if server sent data */
		{
			if((n=read(sockfd,message,MAXLINE))==0)
			{	
				sleep(1);
				return 0;
			}

			for(int i=0;i<n;i++)
				cout<<message[i];
		}
		
		if(FD_ISSET(STDIN_FILENO,&rset)) /* check if stdin */
		{
			fgets(input,MAXLINE,stdin);
		
			bool exit = false;
			if(!strncmp(input,"exit",4)) /* check exit */
			{
				for(int i=4;i<strlen(input);i++)
				{
					if(input[i]!=' ' && input[i]!='\r' && input[i]!='\n')
						break;
					if(i==strlen(input)-1)
					{
						exit  = true;
						break;
					}
				}
			}
		
			if(exit)
			{
				sleep(1);
				return 0;
			}
			write(sockfd,input,strlen(input)); /* write to server */
		}
	}		


}

