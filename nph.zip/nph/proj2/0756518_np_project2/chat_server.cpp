#include <iostream>
//#include "unpv13e/unp.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <signal.h>
#include <unistd.h>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>

#define PORT 5566
#define MAXLINE 4096

using namespace std;

class Connection
{
public:
	char name[13];
	int name_len;
	int sockfd;
	char port[6];
	char address[16];
	Connection(){};

};


void hello_newcli(int ,char*,char*);
void who(vector<Connection>,int);
void change_name(vector<Connection>&table,int,char*,int);
void yell(vector<Connection>,int,char*,int);
void tell(vector<Connection>,int,char*,int,char*,int);


int main(int argc, char **argv)
{
	int listenfd, connfd, sockfd, max_index, maxfd;
	int num_ready,client[FD_SETSIZE];
	pid_t child_pid;
	ssize_t n;
	socklen_t client_len;
	fd_set rset,allset;
	struct sockaddr_in client_addr,server_addr;
	char input[MAXLINE];
	char cliaddr[16],client_port[6];
	vector<Connection> table;
       	Connection user;	
	
	int i;
	char message[MAXLINE];	
	char name[13];

	if ((listenfd = socket(AF_INET,SOCK_STREAM,0)) < 0)
	{
		cout<<"create socket error!"<<endl;
		exit(1);
	}
	
	bzero(&server_addr,sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	server_addr.sin_port = htons(PORT);

  	if(bind(listenfd,(struct sockaddr *) &server_addr,sizeof(server_addr)) < 0)
	{
		cout<<"bind error!"<<endl;
		exit(1);
	}
	listen(listenfd,10); /* set max pending num */
	
	maxfd = listenfd;
	max_index = -1;
	
	for(i=0;i<FD_SETSIZE;i++)	client[i]=-1;
	
	FD_ZERO(&allset); /* clean allset */
	FD_SET(listenfd,&allset); /* add listenfd into allset */


	for(;;)
	{
		rset = allset;
		num_ready = select(maxfd+1,&rset,NULL,NULL,NULL);
		
		if(FD_ISSET(listenfd,&rset)) /* new client connection */
		{
			client_len = sizeof(client_addr);
			connfd = accept(listenfd,(struct sockaddr *) &client_addr,&client_len);
			cout<<"connection from "<<inet_ntop(AF_INET, &client_addr.sin_addr,cliaddr,sizeof(cliaddr))<<", port "<<ntohs(client_addr.sin_port)<<endl; /* show client info in server */
			snprintf(client_port,sizeof(client_port),"%d",(int)ntohs(client_addr.sin_port)); /* turn uint16_t port to char */
			
			hello_newcli(connfd,cliaddr,client_port); /* hello to new client */
			
			/* hello to exist user */
			for(int k=0;k<table.size();k++)
				write(table[k].sockfd,"[Server] Someone is coming!\n",28);

			/* add client info to table */
			strcpy(user.name,"anonymous");
			strcpy(user.port,client_port);
			strcpy(user.address,cliaddr);
			user.sockfd = connfd;
			user.name_len = 9;
			table.push_back(user);


			for(i=0;i<FD_SETSIZE;i++)
			{
				if(client[i]<0)
				{
					client[i] = connfd;
					break;
				}
			}
			
			FD_SET(connfd, &allset);        /* add new descriptor to set */
			
			if (connfd > maxfd)
		                 maxfd = connfd;        /* for select */
                        if (i > max_index)
                                 max_index = i;             /* max index in client[] array */
	                if (--num_ready <= 0)
                                 continue;             /* no more readable descriptors */
		
		
		
		
		}
		
		for (i = 0; i <= max_index; i++)    /* check all clients for data */
		{
			int len;
			if ( (sockfd = client[i]) < 0)
	         	       continue;
                	if (FD_ISSET(sockfd, &rset)) 
			{
	        		if ( (n = read(sockfd, input, MAXLINE)) == 0)           /* connection closed by client */
				{
					for(int k=0;k<table.size();k++)
					{
						if(table[k].sockfd == sockfd)
						{
							for(int j=0;j<table[k].name_len;j++)
								cout<<table[k].name[j];
							cout<<"(from: "<<table[k].address<<":"<<table[k].port<<") is offline."<<endl; /* show offline user info */
							
							/* store info to show for exist user */
							strcpy(name,table[k].name);
							len = table[k].name_len;
							table.erase(table.begin()+k); /* erase user from table */
							break;
						}
					}
					
					for(int k=0;k<table.size();k++)
					{
						write(table[k].sockfd,"[Server] ",9);
						write(table[k].sockfd,name,len);
						write(table[k].sockfd," is offline.\n",13);
					}

					close(sockfd);
		       		        FD_CLR(sockfd, &allset);
		       		        client[i] = -1;
			        } 
				else /* deal with user input */ 
				{
					bool error = false;
					if(!strncmp(input,"who",3))  /* who */
					{
						/*
						for(int k=3;k<n-1;k++)
						{
							if(input[k]==' ' ||input[k]=='\r')
								continue;							
							else
							{
								write(sockfd,"[Server] ERROR: Error command\n",31);
								error = true;
								break;
							}
						}
						*/
						if(input[3]!=' ' && input[3]!='\r' && input[3]!='\n')
							write(sockfd,"[Server] ERROR: Error command\n",31);
						else
							who(table,sockfd);
					}
					else if(!strncmp(input,"name ",5)) /* name */
					{
						bool escape = true;
						int start=0,end=0;

						for(int k=5;k<n-1;k++)
						{
							if(escape && input[k]==' ') /* skip space between cmd and name */
								continue;
							else /* check where name start&end in input */
							{
								if(escape && input[k]!=' ' && input[k]!='\r' && input[k]!='\n') 
								{
									start = k;
									escape = false;
								}
								if(input[k]!=' '&&input[k]!='\r')
									end = k;
							}
						}
						
						int name_len = end-start+1;
						
						if(start==0) /* without user name */
						{
							write(sockfd,"[Server] ERROR: Error command.\n",31);
							continue;
						}
					
						
						for(int k=start;k<=end;k++) /* check if not consist 2~12 letters */
						{
							if(!(input[k]>=65 && input[k]<=90) && !(input[k]>=97  && input[k]<=122))
							{
								error = true;
								break;
							}
						}
						if(error|| name_len<2 || name_len>12)
							write(sockfd,"[Server] ERROR: Username can only consists of 2~12 English letters.\n",68);
						else
						{
							strncpy(name,input+start,name_len);
							if(!strncmp(name,"anonymous",name_len)) /* username can't be anonymous */
							{
								write(sockfd,"[Server] ERROR: Username cannot be anonymous.\n",46);
								continue;
							}
							int name_index;
							for(int k=0;k<table.size();k++)  /* check if name is used */
							{
								if(table[k].sockfd == sockfd)
									name_index = k;
								if(!strncmp(name,table[k].name,name_len)&& name_len == table[k].name_len)
								{
									error = true;
									write(sockfd,"[Server] ERROR: ",16);
									write(sockfd,name,name_len);
									write(sockfd," has been used by others.\n",26);
									break;
								}
							}
							if(!error) /* correct input */
								change_name(table,sockfd,name,name_len);
						}


					}
					else if(!strncmp(input,"yell ",5)) /* yell */
					{
						bool escape = true;
						int start=0,end=0;

						for(int k=5;k<n-1;k++)
						{
							if(escape && input[k]==' ') /* skip space between cmd and message */
								continue;
							else /* check where message start&end in input */
							{
								if(escape && input[k]!=' ' && input[k]!='\r' && input[k]!='\n') 
								{
									start = k;
									escape = false;
								}
								if(input[k]!=' '&&input[k]!='\r')
									end = k;
							}
						}
						int message_len = end-start+1;
						
						if(start==0) /* without message */
						{
							write(sockfd,"[Server] ERROR: Error command.\n",31);
							continue;
						}
						
						strncpy(message,input+start,message_len);
						yell(table,sockfd,message,message_len);
					}
					else if(!strncmp(input,"tell ",5)) /* tell */
					{
						bool escape1 = true,escape2 = true,end_check = false;
						int name_start=0,name_end=0,mes_start=0,mes_end=0;

						for(int k=5;k<n-1;k++)
						{
							if(escape1 && input[k]==' ') /* skip space between cmd and name */
								continue;
							else if(!escape1 && escape2 && input[k]==' ') /* skip space between name and message */
							{
								end_check = true;
								continue;
							}
							else /* check where name start&end in input */
							{
								if(escape1 && input[k]!=' ' && input[k]!='\r') 
								{
									name_start = k;
									escape1 = false;
								}
								else if(!escape1 && escape2 && input[k]!=' ' && input[k]!='\r' && end_check)
								{
									mes_start = k;
									escape2 = false;
								}
								if(!escape1 && escape2 && input[k]!=' ' && input[k]!='\r')
									name_end = k;
								if(!escape2 && input[k]!=' ' && input[k]!='\r')
									mes_end = k;
							}
						}
						int name_len = (name_start==0)? 0:name_end-name_start+1;
						int mes_len = (mes_start==0)? 0:mes_end-mes_start+1;

						if(name_len==0 ||mes_len==0) /* error type */
						{
							write(sockfd,"[Server] ERROR: Error command.\n",31);
							continue;
						}

						strncpy(name,input+name_start,name_len); /* get name and message */
						strncpy(message,input+mes_start,mes_len);
					       		
						tell(table,sockfd,name,name_len,message,mes_len);

					}
					else if(!strncmp(input,"check ",6)) /* */
					{
						bool escape = true;
						int start=0,end=0;

						for(int k=6;k<n-1;k++)
						{
							if(escape && input[k]==' ') /* skip space between cmd and message */
								continue;
							else /* check where message start&end in input */
							{
								if(escape && input[k]!=' ' && input[k]!='\r' && input[k]!='\n') 
								{
									start = k;
									escape = false;
								}
								if(input[k]!=' '&&input[k]!='\r')
									end = k;
							}
						}
						if(start ==0 && end == 0)
						{
							write(sockfd,"[Server] ERROR: Error command.\n",31);
							continue;
						}
						
						int name_len = end-start+1;
						strncpy(name,input+start,name_len);
						bool online = false;
						for(int k=0;k<table.size();k++)
						{
							if(!strncmp(table[k].name,name,name_len) && name_len == table[k].name_len)
							{
								write(sockfd,"[Server] ",9);
								write(sockfd,name,name_len);
								write(sockfd," is online.\n",12);
								online = true;
								break;
							}
						}
						if(!online)
						{
							write(sockfd,"[Server] ",9);
							write(sockfd,name,name_len);
							write(sockfd," doesn't existed.\n",18);
						}
							
					}
					else if(!strncmp(input,"\r\n",2) || !strncmp(input,"\n",1))
						continue;
					else
					{
						write(sockfd,"[Server] ERROR: Error command.\n",31);
					}
				}

				if (--num_ready <= 0)
				        break;                          /* no more readable descriptors */
			}
		}
	}
}

void hello_newcli(int connfd,char* addr,char* port)
{
	write(connfd,"[Server] Hello, anonymous! From: ",33);
	write(connfd,addr,strlen(addr));
	write(connfd,"/",1);
	write(connfd,port,strlen(port));
	write(connfd,"\n",1);
	return;
}

void who(vector<Connection> table,int sockfd)
{
	for(int i=0;i<table.size();i++)
	{
		write(sockfd,"[Server] ",9);
		write(sockfd,table[i].name,table[i].name_len);
		write(sockfd," ",1);
		write(sockfd,table[i].address,strlen(table[i].address));
		write(sockfd,"/",1);
		write(sockfd,table[i].port,strlen(table[i].port));
		if(table[i].sockfd == sockfd)
			write(sockfd," ->me",5);
		write(sockfd,"\n",1);
	}
	return;
}

void change_name(vector<Connection> &table,int sockfd,char* name,int name_len)
{
	char old_name[13];
	int len;
	for(int i=0;i<table.size();i++)
	{
		if(table[i].sockfd == sockfd)
		{
			strncpy(old_name,table[i].name,table[i].name_len);
			len = table[i].name_len;
			write(sockfd,"[Server] You're now known as ",29);
			write(sockfd,name,name_len);
			write(sockfd,".\n",2);
			strncpy(table[i].name,name,name_len);
			table[i].name_len = name_len;
			break;
		}
	}
	for(int i=0;i<table.size();i++)
	{
		if(table[i].sockfd != sockfd)
		{
			write(table[i].sockfd,"[Server] ",9);
			write(table[i].sockfd,old_name,len);
			write(table[i].sockfd," is now known as ",17);
			write(table[i].sockfd,name,name_len);
			write(table[i].sockfd,".\n",2);


		}
	}
	return;
}


void yell(vector<Connection> table,int sockfd,char* message,int message_len)
{
	int user_index;
	for(int i=0;i<table.size();i++)
	{
		if(table[i].sockfd == sockfd)
			user_index = i;
	}
	for(int i=0;i<table.size();i++)
	{
		write(table[i].sockfd,"[Server] ",9);
		write(table[i].sockfd,table[user_index].name,table[user_index].name_len);
		write(table[i].sockfd," yell ",6);
		write(table[i].sockfd,message,message_len);
		write(table[i].sockfd,".\n",2);
	}
	return;
}

void tell(vector<Connection> table,int sockfd,char* name,int name_len,char* message,int mes_len)
{
	int user_index;
	for(int i=0;i<table.size();i++) /* check if sender is anonymous */
	{
		if(table[i].sockfd == sockfd)
		{
			user_index = i;
			if(!strncmp(table[i].name,"anonymous",table[i].name_len))
			{
				write(sockfd,"[Server] ERROR: You are anonymous.\n",35);
				return;
			}
		}
	}

	if(!strncmp(name,"anonymous",name_len)) /* check if receiver is anonymous */
	{
		write(sockfd,"[Server] ERROR: The client to which you sent is anonymous.\n",59);
		return;
	}
	
	for(int i=0;i<table.size();i++) /* check if receiver is exist */
	{
		if(!strncmp(table[i].name,name,name_len) && name_len == table[i].name_len) /* if existed, sent message */
		{
			/* sent message(sender) */
			write(sockfd,"[Server] SUCCESS: Your message has been sent.\n",46);

			/* sent message(receiver) */
			write(table[i].sockfd,"[Server] ",9); 
			write(table[i].sockfd,table[user_index].name,table[user_index].name_len);
			write(table[i].sockfd," tell you ",10);
			write(table[i].sockfd,message,mes_len);
			write(table[i].sockfd,"\n",1);
			return;
		}
	}

	write(sockfd,"[Server] ERROR: The receiver doesn't exist.\n",44);
	return;



}
