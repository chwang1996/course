#! /bin/sh
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
./demo.sh nplinux2.cs.nctu.edu.tw 12346
