#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <csignal>
#include <unistd.h>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>
#include <sstream>
#include <algorithm>
#include <sys/stat.h>

#define PORT 5566
#define MAXLINE 15004

extern char **environ;

using namespace std;

struct Connection
{
	char name[21];
	int sockfd;
	char port[6];
	char address[16];
	vector<char**> env;
	int id;
	int pipeNum_counter[1004][2]; // numbered-pipe counter, store read/write fd
	int user_pipe[30][2];
};

vector<Connection> table;

#include "chat_cmd.h"
void printenv(int,char*);
uint16_t charToint(char*);
void welcome(int);
void login_msg(const char*,const char*);
void logout_msg(char*);
bool sort_ID(Connection,Connection);
bool isValid(const char* cmd);
void unknown(const char* cmd);
void zombie_deal(int sig);
bool cmdExisted(const char*);
static void handler(int sig) { /* do nothing */  }
void user_not_existed(int,int);
void pipe_not_existed(int,int,int);
void not_empty(int,int,int);
void broadcast_write(char*,int,char*,int);
void broadcast_read(char*,int,char*,int);


int main(int argc, char **argv)
{
	int listenfd, connfd, sockfd, max_index, maxfd;
	int num_ready,client[FD_SETSIZE];
	uint16_t port;
	socklen_t client_len;
	fd_set rset,allset;
	struct sockaddr_in client_addr,server_addr;
	char input[MAXLINE];
	char input_bak[MAXLINE];
	char cliaddr[16],client_port[6];
	
    	Connection user;	
	int table_index = 0;
	char **env_temp;
	env_temp = new char *[2];
	
	int k;
	char message[MAXLINE];
	char buffer[10000000];
	char name[21];
	
	char pipeNum_char[8];
	char rbuf[65536];
	bool isRedirect = false;
	int pipeNum_o = 0; //numbered-pipe stdout
	int pipeNum_err = 0; //numbered-pipe stderr/stdout
	int pipeCount = 0; // Num ordinary pipe
	int userpipeNum_o = 0;
	int userpipeNum_i = 0;
	int userpipeNum_i_pos = -1;
	vector<char**> input_cmd;
	
	char **temp_cmd;
	int cmd_counter = 0;
	int n;

	int pipefd[2];
	int pipefd_back[2]; // redirect pipe output to parent
	
	int stdout_fd = dup(1); // save stdout fd
	int stdin_fd = dup(0); // save stdin fd
	int stderr_fd = dup(2);
	
	
	if(argc!=2)
	{
		printf("Usage:./server <port>\n");
		exit(0);
	}
	
	// initialize environment variable
	environ = NULL;
	setenv("PATH","bin:.",1);
	
	// initialize PATH
	memset(buffer,0,sizeof(buffer));	
	memset(rbuf,0,sizeof(rbuf));

	
	
	// create server socket
	if((listenfd = socket(AF_INET,SOCK_STREAM,0)) < 0)
	{
		printf("create socket error!\n");
		exit(1);
	}
	
	bzero(&server_addr,sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	server_addr.sin_port = htons(charToint(argv[1]));
	
	// bind addrees to the server socket
  	if(bind(listenfd,(struct sockaddr *) &server_addr,sizeof(server_addr)) < 0)
	{
		printf("bind error!\n");
		exit(1);
	}
	// set max pending num
	listen(listenfd,10); 
	
	maxfd = listenfd;
	max_index = -1;
	
	for(k=0;k<FD_SETSIZE;k++)	client[k]=-1;
	
	// clean allset
	FD_ZERO(&allset); 
	// add listenfd into allset
	FD_SET(listenfd,&allset); 


	for(;;)
	{
		rset = allset;
		num_ready = select(maxfd+1,&rset,NULL,NULL,NULL);
		if(num_ready<0) continue;
		
		// new client connection
		if(FD_ISSET(listenfd,&rset)) 
		{
			client_len = sizeof(client_addr);
			connfd = accept(listenfd,(struct sockaddr *) &client_addr,&client_len);
			
			// show client info in server
			printf("New connection from %s/%d\n",inet_ntop(AF_INET, &client_addr.sin_addr,cliaddr,sizeof(cliaddr)),ntohs(client_addr.sin_port));
			
			// turn uint16_t port to char
			snprintf(client_port,sizeof(client_port),"%d",(int)ntohs(client_addr.sin_port)); 
			
			// welcome to new client
			welcome(connfd); 

			// add client info to table
			memset(user.name,0,sizeof(user.name));
			memset(user.port,0,sizeof(user.port));
			memset(user.address,0,sizeof(user.address));
			user.id = -1;			
			user.env.clear();
	
			strcpy(user.name,"(no name)");
			strcpy(user.port,client_port);
			strcpy(user.address,cliaddr);
			*(env_temp) = new char[strlen("PATH")+1];
			memset(*(env_temp),0,sizeof(*(env_temp)));
			strcpy(*(env_temp),"PATH");
			*(env_temp+1) = new char[strlen("bin:.")+1];
			memset(*(env_temp+1),0,sizeof(*(env_temp+1)));
			strcpy(*(env_temp+1),"bin:.");
			
			user.env.push_back(env_temp);			
			
			user.sockfd = connfd;
			
			// initialize numbered-pipe counter
			for(int i=0;i<1004;i++)
			{
				user.pipeNum_counter[i][0] = -1;
				user.pipeNum_counter[i][1] = -1;
			}
			
			// initialize user pipe
			for(int i=0;i<30;i++)
			{
				user.user_pipe[i][0] = -1;
				user.user_pipe[i][1] = -1;
			}			

			for(k=0;k<FD_SETSIZE;k++)
			{
				if(client[k]<0)
				{
					client[k] = connfd;
					user.id = k+1;
					break;
				}
			}
			
			table.push_back(user);
			
			// sort table with ID
			sort(table.begin(),table.end(),sort_ID);
				
			// broadcast new user info to all user
			//login_msg(cliaddr,client_port);
			login_msg("CGILAB","511");
						

			write(connfd,"% ",2);
			
			
			// add new descriptor to set
			FD_SET(connfd, &allset);        
			
			if (connfd > maxfd) // for select
		        maxfd = connfd;        
          		if (k > max_index) // max index in client[] array
               		max_index = k;             
	        	if (--num_ready <= 0) // no more readable descriptors 
                	continue;             
		}
		
		//check all clients for data
		for (k = 0; k <= max_index; k++)
		{
			int len;
			if ( (sockfd = client[k]) < 0) continue;
			
  		        if (FD_ISSET(sockfd, &rset)) 
			{
				memset(input,0,sizeof(input));
				if ( (n = read(sockfd, input, MAXLINE)) == 0)  // connection closed by client
				{
					int id_left = 0;
					for(int i=0;i<table.size();i++)
					{
						if(table[i].sockfd == sockfd)
						{
							id_left = table[i].id;
							// clean numbered pipe
							for(int j=0;j<1004;j++)
							{
								if(table[i].pipeNum_counter[j][0]!=-1)
								{
									close(table[i].pipeNum_counter[j][0]);
									close(table[i].pipeNum_counter[j][1]);
								}
							}
							// clean user pipe
							for(int j=0;j<30;j++)
							{
								if(table[i].user_pipe[j][0] != -1)
								{
									close(table[i].user_pipe[j][0]);
									close(table[i].user_pipe[j][1]);
								}
							}	
													
	
							printf("User: %s,from: %s/%s is offline.\n",table[i].name,table[i].address,table[i].port);
							
							// store info to show for exist user
							memset(name,0,sizeof(name));
							strcpy(name,table[i].name);
							
							// erase user from table
							table.erase(table.begin()+i); 
						}
					}
					
					// clean user pipe
					for(int i=0;i<table.size();i++)
					{
						if(table[i].user_pipe[id_left-1][0] != -1)
						{
							close(table[i].user_pipe[id_left-1][0]);					
							close(table[i].user_pipe[id_left-1][1]);					
							
							table[i].user_pipe[id_left-1][0] = -1;					
							table[i].user_pipe[id_left-1][1] = -1;					
						}
					}
			
					logout_msg(name);
					

					close(sockfd);
		       			FD_CLR(sockfd, &allset);
		       			client[k] = -1;
			    	} 
				else /* deal with user input */ 
				{
					for(int i=0;i<table.size();i++)
					{
						if(table[i].sockfd == sockfd)
						{
							table_index = i;
							break;
						}
					}
					
					// set user env to environ
					environ = NULL;
					for(int i=0;i<table[table_index].env.size();i++) setenv(*(table[table_index].env[i]),*(table[table_index].env[i]+1),1);					
					
					//initialize flag
					isRedirect = false;
					pipeNum_o = 0;
					pipeNum_err = 0;
					userpipeNum_o = 0;
					userpipeNum_i = 0;
					userpipeNum_i_pos = -1;
					pipeCount = 0;
					temp_cmd = new char*[10];
					cmd_counter = 0;
					
					// backup input
					memset(input_bak,0,sizeof(input_bak));
					strcpy(input_bak,input);

					//split input
					char* hold = strtok(input," ");
					
					while(hold)
					{
						// remove newline of input data
						if(*(hold + strlen(hold)-1) == '\n') *(hold+strlen(hold)-1) = '\0';
						if(*(hold + strlen(hold)-1) == '\r') *(hold+strlen(hold)-1) = '\0';
						if(strlen(hold) == 0) break;						

						//check if redirect/pipe/numbered-pipe(stdout/stdout&stderr)
						if(!strcmp(hold,">"))
						{
							isRedirect = true;
							*(temp_cmd + cmd_counter) = NULL;
							input_cmd.push_back(temp_cmd); // store command line into vector
							temp_cmd = new char*[10];
							cmd_counter = 0;
						}
						else if((!strncmp(hold,">",1) || !strncmp(hold,"<",1) ) && strlen(hold)!=1 )
						{
							memset(pipeNum_char,0,8);
							strncpy(pipeNum_char,hold+1,strlen(hold)-1);
							int num = atoi(pipeNum_char);
							int temp = num;
							int len = 0;
							while(temp) //get integer length
							{
								len++;
								temp/=10;
							}
							
							if(len == strlen(pipeNum_char)) //check if char array are all number
							{
								if(!strncmp(hold,">",1)) userpipeNum_o = num;  // output_index = input_ID -1
								else 
								{
									userpipeNum_i = num; // input_index = input_ID -1
									userpipeNum_i_pos = pipeCount;
								}
							}
							else
							{
								printf("Error numbered-pipes!\n");
								exit(0);
							} 	

						}
						else if(!strcmp(hold,"|"))
						{
							pipeCount++;
							*(temp_cmd + cmd_counter) = NULL;
							input_cmd.push_back(temp_cmd); // store command line into vector
							temp_cmd = new char*[10];
							cmd_counter = 0;

						}
						else if((!strncmp(hold,"|",1) || !strncmp(hold,"!",1) ) && strcmp(hold,"|"))
						{
							//convert char array to int
							memset(pipeNum_char,0,8);
							strncpy(pipeNum_char,hold+1,strlen(hold)-1);
							int num = atoi(pipeNum_char);
							int temp = num;
							int len = 0;
							while(temp) //get integer length
							{
								len++;
								temp/=10;
							}

							if(len == strlen(pipeNum_char)) //check if char array are all number
							{
								if(!strncmp(hold,"|",1))pipeNum_o = num;
								else pipeNum_err = num;
							}
							else
							{
								printf("Error numbered-pipes!\n");
								exit(0);
							}
						}
						else // command token
						{

							*(temp_cmd + cmd_counter) = new char[strlen(hold)+1];
							memset(*(temp_cmd + cmd_counter),0,sizeof(*(temp_cmd + cmd_counter)));
							strcpy(*(temp_cmd+cmd_counter++),hold);
						}

						hold = strtok(NULL," ");
					}
					*(temp_cmd + cmd_counter) = NULL;
					
					input_cmd.push_back(temp_cmd); // store last command line into vector
					
					// check if input is empty
					if(*(input_cmd[0]) == NULL)
					{
						input_cmd.clear();
						write(table[table_index].sockfd,"% ",2);
						continue;
					}
					
					// substract counter
					for(int i=0;i<1004;i++)
					{
						if(i!=1003)
						{
							table[table_index].pipeNum_counter[i][0] = table[table_index].pipeNum_counter[i+1][0];
							table[table_index].pipeNum_counter[i][1] = table[table_index].pipeNum_counter[i+1][1];
						}
						else
						{
							table[table_index].pipeNum_counter[i][0] = -1;
							table[table_index].pipeNum_counter[i][0] = -1;
						}
						
					}
					
					// execute default command
					if(!strcmp(*(input_cmd[0]),"setenv"))
					{
						setenv(*(input_cmd[0]+1),*(input_cmd[0]+2),1);
						
						env_temp = NULL;
						env_temp = new char *[2];
						// store into env table
						*(env_temp) = new char[strlen(*(input_cmd[0]+1))+1];
						memset(*(env_temp),0,sizeof(*(env_temp)));
						strcpy(*(env_temp),*(input_cmd[0]+1));
						*(env_temp+1) = new char[strlen(*(input_cmd[0]+2))+1];
						memset(*(env_temp+1),0,sizeof(*(env_temp+1)));
						strcpy(*(env_temp+1),*(input_cmd[0]+2));
						table[table_index].env.push_back(env_temp);			

						input_cmd.clear();
						write(sockfd,"% ",2);
						continue;
					}
					else if(!strcmp(*(input_cmd[0]),"printenv")) 
					{
						printenv(sockfd,*(input_cmd[0]+1));
						input_cmd.clear();
						write(sockfd,"% ",2);
						continue;
					}
					else if(!strcmp(*(input_cmd[0]),"who")) 
					{
						who(sockfd);
						input_cmd.clear();
						write(sockfd,"% ",2);
						continue;
					}
					else if(!strcmp(*(input_cmd[0]),"name"))
					{
						if(valid_name(table_index,*(input_cmd[0]+1))) change_name(table_index,*(input_cmd[0]+1));
						input_cmd.clear();
						write(sockfd,"% ",2);
						continue;
					}
					else if(!strcmp(*(input_cmd[0]),"yell"))
					{
						yell(table[table_index].name,input_bak);
						input_cmd.clear();
						write(sockfd,"% ",2);
						continue;
					}
					else if(!strcmp(*(input_cmd[0]),"tell"))
					{
						tell(table[table_index].sockfd,table[table_index].name,*(input_cmd[0]+1),input_bak);
						input_cmd.clear();
						write(sockfd,"% ",2);
						continue;
					}
					else if(!strcmp(*(input_cmd[0]),"exit"))
					{	
						// clean numbered pipe
						for(int j=0;j<1004;j++)
						{
							if(table[table_index].pipeNum_counter[j][0]!=-1)
							{
								close(table[table_index].pipeNum_counter[j][0]);
								close(table[table_index].pipeNum_counter[j][1]);
							}
						}
						// clean user pipe
						for(int j=0;j<30;j++)
						{
							if(table[table_index].user_pipe[j][0] != -1)
							{
								close(table[table_index].user_pipe[j][0]);
								close(table[table_index].user_pipe[j][1]);
							}
						}	
						
						for(int i=0;i<table.size();i++)
						{
							if(i!=table_index && table[i].user_pipe[table[table_index].id-1][0] != -1)
							{
								close(table[i].user_pipe[table[table_index].id-1][0]);
								close(table[i].user_pipe[table[table_index].id-1][1]);
								table[i].user_pipe[table[table_index].id-1][0] = -1;
								table[i].user_pipe[table[table_index].id-1][0] = -1;
							}

						}							

						printf("User: %s,from: %s/%s is offline.\n",table[table_index].name,table[table_index].address,table[table_index].port);
						
						// store info to show for exist user
						memset(name,0,sizeof(name));
						strcpy(name,table[table_index].name);
						
						logout_msg(name);
						// erase user from table
						table.erase(table.begin()+table_index); 

						close(sockfd);
		       				FD_CLR(sockfd, &allset);
		       				client[k] = -1;

						input_cmd.clear();
						continue;
					}
					
					// get sender index in table
					int sender_index = -1;
					for(int i=0;i<table.size();i++)
					{
						if(table[i].id == userpipeNum_i)
						{
							sender_index = i;
							break;
						}
					}	
					
					for(int i=0;i<=pipeCount;i++)
					{
						pid_t pid;
						pipe(pipefd);
						pipe(pipefd_back);
			
						pid = fork();
			
						if(pid < 0)
						{
							printf("Fork failed!!\n");
							exit(-1);
						}
						else if(pid == 0) // child
						{
							// check if numbered-pipe output as stdin
							if(table[table_index].pipeNum_counter[0][0] != -1 && i == 0)
							{
								close(table[table_index].pipeNum_counter[0][1]);
								dup2(table[table_index].pipeNum_counter[0][0],0);
								close(table[table_index].pipeNum_counter[0][0]);
							}
							
							if(i == userpipeNum_i_pos)
							{
								if(client[userpipeNum_i-1] == -1) // sender not existed
								{
									close(pipefd[0]);
									close(pipefd[1]);
									close(pipefd_back[0]);	
									close(pipefd_back[1]);
									user_not_existed(table[table_index].sockfd,userpipeNum_i);
									exit(0);
								}
								else if(table[sender_index].user_pipe[table[table_index].id-1][0] == -1)
								{
									close(pipefd[0]);
									close(pipefd[1]);
									close(pipefd_back[0]);	
									close(pipefd_back[1]);
									pipe_not_existed(table[table_index].sockfd,table[table_index].id,userpipeNum_i);
									exit(0);
								}
								close(table[sender_index].user_pipe[table[table_index].id-1][1]);
								dup2(table[sender_index].user_pipe[table[table_index].id-1][0],0);
								close(table[sender_index].user_pipe[table[table_index].id-1][0]);
							}
				
							close(pipefd[1]);
							// first round may have numbered-pipe input, can't use parent pipe input as stdin
							if(i!=0 && i!=userpipeNum_i_pos) dup2(pipefd[0],0);
							close(pipefd[0]);
				
							// last round, need to redirect output directly instead of pipe to parent	
							if(i == pipeCount)
							{
								if(isRedirect && isValid(*(input_cmd[i]))) // file redirect
								{
									FILE* fptr;
									fptr = fopen(*(input_cmd[input_cmd.size()-1]),"w");
									dup2(fileno(fptr),1);
									dup2(table[table_index].sockfd,2);
									execvp(*(input_cmd[i]),input_cmd[i]);	
								}
								else if(pipeNum_o != 0) // numbered-pipe (stdout)
								{
									// if the pipe is existed, reuse it, if not, redirect output to the new pipe,
									// and the new pipefd would be stored in parent.
									if(table[table_index].pipeNum_counter[pipeNum_o][0] !=-1)
									{
										close(pipefd_back[0]);
										close(pipefd_back[1]);
										dup2(table[table_index].pipeNum_counter[pipeNum_o][1],1);
										dup2(table[table_index].sockfd,2);
									}
									else
									{
										close(pipefd_back[0]);
										dup2(pipefd_back[1],1);
										dup2(table[table_index].sockfd,2);
										close(pipefd_back[1]);
									}
									// check input command is valid or not
									if(!isValid(*(input_cmd[i])))
									{
										unknown(*(input_cmd[i]));
										exit(0);
									}
									else execvp(*(input_cmd[i]),input_cmd[i]);
								}
								else if(pipeNum_err != 0) // numbered-pipe (stdout & stderr)
								{
									if(table[table_index].pipeNum_counter[pipeNum_err][0] !=-1)
									{
										close(pipefd_back[0]);
										close(pipefd_back[1]);
										dup2(table[table_index].pipeNum_counter[pipeNum_err][1],1);
										dup2(table[table_index].pipeNum_counter[pipeNum_err][1],2); // also pipe output to stderr
									}
									else
									{
										close(pipefd_back[0]);
										dup2(pipefd_back[1],1);
										dup2(pipefd_back[1],2);
										close(pipefd_back[1]);
									}
									if(!isValid(*(input_cmd[i]))) 
									{
										unknown(*(input_cmd[i]));
										exit(0);
									}
									else 									
									{
										execvp(*(input_cmd[i]),input_cmd[i]);
									}
							
								}
								else if(userpipeNum_o !=0)
								{
									if(client[userpipeNum_o-1] == -1) // receiver not existed
									{
										close(pipefd_back[0]);
										close(pipefd_back[1]);
										user_not_existed(table[table_index].sockfd,userpipeNum_o);
										exit(0);
									}
									else if(table[table_index].user_pipe[userpipeNum_o-1][0] != -1) // receiver's pipe not empty
									{
										close(pipefd_back[0]);
										close(pipefd_back[1]);
										not_empty(table[table_index].sockfd,table[table_index].id,userpipeNum_o);
										exit(0);
									}
									else
									{
										close(pipefd_back[0]);
										dup2(pipefd_back[1],1);
										dup2(pipefd_back[1],2);
										close(pipefd_back[1]);
										
										if(!isValid(*(input_cmd[i]))) 
										{
											unknown(*(input_cmd[i]));
											exit(0);
										}
										else 	
										{
											execvp(*(input_cmd[i]),input_cmd[i]);
										}

									}


								}
								else
								{	
									close(pipefd_back[0]);
									//dup2(stdout_fd,1);
									dup2(table[table_index].sockfd,1);
									dup2(table[table_index].sockfd,2);
									close(pipefd_back[1]);
									
									if(!isValid(*(input_cmd[i]))) 
									{
										unknown(*(input_cmd[i]));
										exit(0);
									}
									else execvp(*(input_cmd[i]),input_cmd[i]);
								}
							}
							else // not last round
							{
								close(pipefd_back[0]);
								dup2(pipefd_back[1],1);
								dup2(table[table_index].sockfd,2);
								close(pipefd_back[1]);
									
								if(!isValid(*(input_cmd[i]))) 
								{
									unknown(*(input_cmd[i]));
									exit(0);
								}
								else execvp(*(input_cmd[i]),input_cmd[i]);
							}
						}
						else // parent
						{
							// if numbered-pipe output already as stdin in this round, close the fd
							if(table[table_index].pipeNum_counter[0][0] != -1 && i == 0)
							{		
								close(table[table_index].pipeNum_counter[0][0]);
								close(table[table_index].pipeNum_counter[0][1]);
							}
							
							if(i == userpipeNum_i_pos && table[sender_index].user_pipe[table[table_index].id-1][0] != -1)
							{
								close(table[sender_index].user_pipe[table[table_index].id-1][0]);
								close(table[sender_index].user_pipe[table[table_index].id-1][1]);
											
								table[sender_index].user_pipe[table[table_index].id-1][0] = -1;
								table[sender_index].user_pipe[table[table_index].id-1][0] = -1;
								broadcast_read(table[table_index].name,table[table_index].id,input_bak,userpipeNum_i);
							}
						

							// if not first round parent may need to pipe the previous round's stdout as next round's stdin
							// I would store previous round's output into buffer and write to pipe in this round
							// since I dup pipefd write to stdout, so it won't get the EOF when I finish write
							// so I dup stdout fd to stdout to overwritten the fd, so the pipe would close and send EOF automatically.
							//
							// (addition) fork another child to send data, prevent large data block the pipe
							// since previous version, it would stock at write, although child is reading from pipefd and write to pipefd_back,
							// but if data large than 2*65535, the pipefd_back and pipefd would be full, parent write would be block.
							pid_t opid;
							if(i != 0)
							{
								opid = fork();
						
								if(opid < 0)
								{
									printf("Fork Failed!\n");
									exit(-1);
								}		
								else if(opid == 0)
								{
									close(pipefd[0]);
									dup2(pipefd[1],1);
									close(pipefd[1]);
									write(1,buffer,strlen(buffer));
									dup2(stdout_fd,1);
							
									close(pipefd_back[0]);
									close(pipefd_back[1]);
									exit(0);
								}
								close(pipefd[0]);
								close(pipefd[1]);
							}
							else
							{
								close(pipefd[0]);
								close(pipefd[1]);
							}
				
							// not last round, need to read output from child 
							if(i!=pipeCount)
							{					
							
								// close the pipefd_back write, because it only need to read the command output from child
								close(pipefd_back[1]);
								dup2(pipefd_back[0],0);
								close(pipefd_back[0]);
					
								// clear buffer to ensure not mix with the previous round data
								memset(buffer,0,sizeof(buffer));
								memset(rbuf,0,sizeof(rbuf));
								while(((n = read(0,rbuf,sizeof(rbuf))) >0))
								{
									strcat(buffer,rbuf);
									memset(rbuf,0,sizeof(rbuf));
								}
					
								int status;
								waitpid(pid,&status,0);
								//signal(SIGCHLD,zombie_deal);
				
							}
							else // last round, only need to close pipefd and wait for child and store pipefd if there is numbered-pipe
							{
					
								if(pipeNum_o !=0 || pipeNum_err !=0)
								{
									if(table[table_index].pipeNum_counter[pipeNum_o][0] !=-1)
									{
										close(pipefd_back[1]);
										close(pipefd_back[0]);
									}
									else
									{	
										int num = pipeNum_o>pipeNum_err?pipeNum_o:pipeNum_err;
										table[table_index].pipeNum_counter[num][0] = pipefd_back[0];
										table[table_index].pipeNum_counter[num][1] = pipefd_back[1];
									}
									signal(SIGCHLD,zombie_deal);
								}
								else if(userpipeNum_o != 0)
								{
									// receiver not existed / receiver's pipe not empty
									if(client[userpipeNum_o-1] == -1 || table[table_index].user_pipe[userpipeNum_o-1][0] != -1 ) 
									{
										close(pipefd_back[1]);
										close(pipefd_back[0]);
									
										int status;
										waitpid(pid,&status,0);
									}
									else
									{
										table[table_index].user_pipe[userpipeNum_o-1][0] = pipefd_back[0];
										table[table_index].user_pipe[userpipeNum_o-1][1] = pipefd_back[1];
									
										broadcast_write(table[table_index].name,table[table_index].id,input_bak,userpipeNum_o);

										signal(SIGCHLD,zombie_deal);
									}
	
								}
								else
								{
									close(pipefd_back[1]);
									close(pipefd_back[0]);
								
									int status;
									waitpid(pid,&status,0);
								}
							}
							// wait for the output child 
							int status;
							waitpid(opid,&status,0);
						}
						usleep(1000);
					} // end of pipeCount loop
					dup2(stdin_fd,0);
					
					input_cmd.clear();
					
					write(sockfd,"% ",2);
				}
				// no more readable descriptors
				if (--num_ready <= 0) break;
			}
			
		}
	}
}

// print environment variable
void printenv(int sockfd,char* env_name)
{
	if(getenv(env_name) != NULL) 
	{
		write(sockfd,getenv(env_name),strlen(getenv(env_name)));
		write(sockfd,"\n",1);
	}
}

uint16_t charToint(char* port_char)
{
	uint16_t port;
	stringstream ss;
	ss<<port_char;
	ss>>port;
	return port;
}


void welcome(int connfd)
{
	write(connfd,"****************************************\n",41);
	write(connfd,"** Welcome to the information server. **\n",41);
	write(connfd,"****************************************\n",41);
	return;
}

void login_msg(const char* addr,const char* port)
{
	char str[100];
	for(int i=0;i<table.size();i++)
	{
		memset(str,0,100);
		sprintf(str,"*** User '(no name)' entered from %s/%s. ***\n",addr,port);
		write(table[i].sockfd,str,strlen(str));
	}
}

void logout_msg(char* name)
{
	char str[100];
	memset(str,0,100);
	sprintf(str,"*** User '%s' left. ***\n",name);
	for(int i=0;i<table.size();i++)
	{
		write(table[i].sockfd,str,strlen(str));
	}
}


bool sort_ID(Connection lhs,Connection rhs)
{
	return lhs.id < rhs.id;
}

// check command is existed in environment PATH or not
bool cmdExisted(const char* cmd)
{
	char *path = strtok(getenv("PATH"),":");
	char file[12+strlen(cmd)];

	struct stat buf;
	// split printenv return to single path,and check the command is existed or not
	while(path)
	{
		memset(file,0,sizeof(file));
		snprintf(file,sizeof(file),"./%s/%s",path,cmd);	
		if(stat(file,&buf) == 0)  return true;		

		path = strtok(NULL,":");
	}	
		
	return false;

}

// check input command is valid or not
bool isValid(const char* cmd)
{
	if(cmdExisted(cmd)) return true;
	else return false;
}

// print invalid command Error msg
void unknown(const char* cmd)
{
	char err[21+strlen(cmd)];
	memset(err,0,sizeof(err));	
	sprintf(err,"Unknown command: [%s].\n",cmd);
	write(2,err,sizeof(err));
}

void zombie_deal(int sig)
{
	int status;
	waitpid(0,&status,WNOHANG);
	//while(waitpid(-1,&status,WNOHANG)>0){}
}

void user_not_existed(int sockfd,int id)
{
	char str[60];
	memset(str,0,60);
	sprintf(str,"*** Error: user #%d does not exist yet. ***\n",id);
		
	write(sockfd,str,strlen(str));
}

void pipe_not_existed(int sockfd,int receiverID,int senderID)
{
	char str[60];
	memset(str,0,60);
	sprintf(str,"*** Error: the pipe #%d->#%d does not exist yet. ***\n",senderID,receiverID);	

	write(sockfd,str,strlen(str));

}

void not_empty(int sockfd,int senderID,int receiverID)
{
	char str[60];
	memset(str,0,60);
	sprintf(str,"*** Error: the pipe #%d->#%d already exists. ***\n",senderID,receiverID);	

	write(sockfd,str,strlen(str));
}

void broadcast_write(char* sendername,int senderID,char* input,int receiverID)
{
	if(input[strlen(input)-1] == '\n') input[strlen(input)-1] = '\0';
	if(input[strlen(input)-1] == '\r') input[strlen(input)-1] = '\0';



	int receiver_table_index;
	for(int i=0;i<table.size();i++)
	{
		if(table[i].id == receiverID)
		{
			receiver_table_index = i;
			break;
		}
	}
	
	char str[15100];
	memset(str,0,15100);
	sprintf(str,"*** %s (#%d) just piped '%s' to %s (#%d) ***\n",sendername,senderID,input,table[receiver_table_index].name,receiverID);
	
	for(int i=0;i<table.size();i++)
	{
		write(table[i].sockfd,str,strlen(str));
	}




}


void broadcast_read(char* receivername,int receiverID,char* input,int senderID)
{
	if(input[strlen(input)-1] == '\n') input[strlen(input)-1] = '\0';
	if(input[strlen(input)-1] == '\r') input[strlen(input)-1] = '\0';
	

	int sender_table_index;
	for(int i=0;i<table.size();i++)
	{
		if(table[i].id == senderID)
		{
			sender_table_index = i;
			break;
		}
	}
	
	char str[15100];
	memset(str,0,15100);
	sprintf(str,"*** %s (#%d) just received from %s (#%d) by '%s' ***\n",receivername,receiverID,table[sender_table_index].name,senderID,input);

	
	for(int i=0;i<table.size();i++)
	{
		write(table[i].sockfd,str,strlen(str));
	}


}
