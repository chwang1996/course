/*
	chat command:
	who:
		Usage: who
	name:
		Usage: name <new_name>
	tell:
		Usage: tell <UserID> <Message>
	yell:
		Usage: yell <Message>
*/
void who(int sockfd)
{
	write(sockfd,"<ID> <nickname>           <IP/port>             <indicate me>\n",62);
	char str[60];
	
	for(int i=0;i<table.size();i++)
	{
		memset(str,0,sizeof(str));
		//if(table[i].sockfd == sockfd) snprintf(str,55,"%-5d%-21s%s/%-*s<-me\n",table[i].id,table[i].name,table[i].address,21-strlen(table[i].address),table[i].port);
		//else snprintf(str,50,"%-5d%-21s%s/%-*s\n",table[i].id,table[i].name,table[i].address,21-strlen(table[i].address),table[i].port);
		if(table[i].sockfd == sockfd) snprintf(str,55,"%-5d%-21s%s/%-*s<-me\n",table[i].id,table[i].name,"CGILAB",15,"511");
		else snprintf(str,50,"%-5d%-21s%s/%-*s\n",table[i].id,table[i].name,"CGILAB",15,"511");
	

		write(sockfd,str,strlen(str));
	}
	return;
}

bool valid_name(int table_index,char *new_name)
{
	// check name length
	if(strlen(new_name) > 20) 
	{
		write(table[table_index].sockfd,"*** User name can't exceed 20 letters. ***\n",43);
		return false;
	}
	
	// check name letter
	for(int i=0;i<strlen(new_name);i++)
	{
		if((*(new_name+i) <48 || *(new_name+i) > 57 ) && (*(new_name+i) <65 || *(new_name+i) > 90 ) && (*(new_name+i) <97 || *(new_name+i) > 122 ))
		{
			write(table[table_index].sockfd,"*** There are only alphabet and digits in names. ***\n",53);
			return false;
		}
	}
	
	// check existed
	for(int i=0;i<table.size();i++)
	{
		if(!strcmp(table[i].name,new_name))
		{
			write(table[table_index].sockfd,"*** User '",10);
			write(table[table_index].sockfd,new_name,strlen(new_name));
			write(table[table_index].sockfd,"' already exists. ***\n",22);
			return false;
		}
	}
	
	return true;
	
}

void change_name(int table_index,char* new_name)
{
	memset(table[table_index].name,0,sizeof(table[table_index].name));
	strcpy(table[table_index].name,new_name);
	
	char str[60];
	memset(str,0,60);
	//sprintf(str,"*** User from %s/%s is named '%s'. ***\n",table[table_index].address,table[table_index].port,new_name);	
	sprintf(str,"*** User from %s/%s is named '%s'. ***\n","CGILAB","511",new_name);	
	
	// broadcast new name to all user
	for(int i=0;i<table.size();i++)
	{
		write(table[i].sockfd,str,strlen(str));
	}
}


void yell(char* name, char* input)
{
	if(input[strlen(input)-1] == '\n') input[strlen(input)-1] = '\0';
	if(input[strlen(input)-1] == '\r') input[strlen(input)-1] = '\0';

	char* hold = strtok(input," ");	
	char* msg = strtok(NULL,"");
	
	char str[10000];
	memset(str,0,10000);
	sprintf(str,"*** %s yelled ***: %s\n",name,msg);	

	for(int i=0;i<table.size();i++)
	{
		write(table[i].sockfd,str,strlen(str));
	}
}


void tell(int sockfd,char* name,char* id,char* input)
{
	if(input[strlen(input)-1] == '\n') input[strlen(input)-1] = '\0';
	if(input[strlen(input)-1] == '\r') input[strlen(input)-1] = '\0';
	
	char* hold = strtok(input," ");	
	hold = strtok(NULL," ");	
	char* msg = strtok(NULL,"");	

	char str[10000];
	memset(str,0,10000);
	sprintf(str,"*** %s told you ***: %s\n",name,msg);	
	
	for(int i=0;i<table.size();i++) // check if receiver is exist
	{
		if(table[i].id == atoi(id)) // if existed, sent message
		{
			write(table[i].sockfd,str,strlen(str));
			return;
		}
	}
	
	// error msg of non-existed user ID
	write(sockfd,"*** Error: user #",17);
	write(sockfd,id,strlen(id));
	write(sockfd," does not exist yet. ***\n",25);
	return;
}


